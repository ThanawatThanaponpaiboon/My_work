%% read file from CSV file
filename = "water_potability.csv";
tbl = readtable(filename,'TextType','String');

%% Checkmissing value and fill with mean
%TF_checkmissing = sum(ismissing(tbl));

%Fill missing with mean value
A = fillmissing(tbl,'constant',7.0860,'DataVariables',{'ph'});
B = fillmissing(A,'constant',333.22 ,'DataVariables',{'Sulfate'});
T_mean = fillmissing(B,'constant', 66.401 ,'DataVariables',{'Trihalomethanes'});

%% Split Data into two sets Train(80) and Test(20)
tb=T_mean;
hpartition = cvpartition(size(tb,1),'Holdout',0.2); % Nonstratified partition
% Extract indices for training and test 
trainId = training(hpartition);
testId = test(hpartition);
% Use Indices to parition the matrix  
trainData = tb(trainId,:);
testData = tb(testId,:);

X_train = trainData(:,1:9);
y_train = trainData(:,"Potability");
%%
X_train= normalize(X_train); % Standardized Data into same scale
save('testdata_RT',"testData") % Save test data for evaluation
%%
t = templateTree('Reproducible',true);
Mdl = fitcensemble(X_train,y_train,'OptimizeHyperparameters','auto','Learners',t, ...
    'HyperparameterOptimizationOptions',struct('AcquisitionFunctionName','expected-improvement-plus'))
%%
y_predict= predict(Mdl,X_train);
y_train_check= y_train{:,:};
confusion_score(y_train_check,y_predict)
%%
save("RF_final_model.mat",'Mdl')

%%
function confusion_score(x,y)
cm= confusionmat(x, y);
cmt = cm';

diagonal = diag(cmt);
sum_of_rows = sum(cmt, 2);

precision = diagonal ./ sum_of_rows;
RF_precision = mean(precision)

sum_of_columns = sum(cmt, 1);
recall = diagonal ./ sum_of_columns';
RF_recall = mean(recall)

RF_f1_score = 2*((RF_precision*RF_recall)/(RF_precision+RF_recall))
RF_Accuracy= (diagonal(1,1)+diagonal(2,1))/(sum_of_rows(1,1)+sum_of_rows(2,1))

figure
confusionchart(x,y)
title('Confusing Matrix')
end
