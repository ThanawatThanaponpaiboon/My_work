load("testdata_RT.mat") %load test dataset
load("RF_final_model.mat") %load final decision tree model

X_test=testData(:,1:9);
X_test= normalize(X_test);
y_test=testData{:,"Potability"};

%check the performance when perform on Testset
y_predict= predict(Mdl,X_test);
confusion_score(y_test,y_predict)

%%
function confusion_score(x,y)
cm= confusionmat(x, y);
cmt = cm';

diagonal = diag(cmt);
sum_of_rows = sum(cmt, 2);

precision = diagonal ./ sum_of_rows;
RF_precision = mean(precision)

sum_of_columns = sum(cmt, 1);
recall = diagonal ./ sum_of_columns';
RF_recall = mean(recall)

RF_f1_score = 2*((RF_precision*RF_recall)/(RF_precision+RF_recall))
RF_Accuracy= (diagonal(1,1)+diagonal(2,1))/(sum_of_rows(1,1)+sum_of_rows(2,1))

figure
confusionchart(x,y)
title('Confusing Matrix')
end