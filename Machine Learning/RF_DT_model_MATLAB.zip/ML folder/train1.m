%% read file from CSV file
filename = "water_potability.csv";
tbl = readtable(filename,'TextType','String');

%% Checkmissing value and fill with mean
%TF_checkmissing = sum(ismissing(tbl));

%Fill missing with mean value
A = fillmissing(tbl,'constant',7.0860,'DataVariables',{'ph'});
B = fillmissing(A,'constant',333.22 ,'DataVariables',{'Sulfate'});
T_mean = fillmissing(B,'constant', 66.401 ,'DataVariables',{'Trihalomethanes'});

%% Split Data into two sets Train(80) and Test(20)
tb=T_mean;
hpartition = cvpartition(size(tb,1),'Holdout',0.2); % Nonstratified partition
% Extract indices for training and test 
trainId = training(hpartition);
testId = test(hpartition);
% Use Indices to parition the matrix  
trainData = tb(trainId,:);
testData = tb(testId,:);

X_train = trainData(:,1:9);
y_train = trainData(:,"Potability");
%%
X_train= normalize(X_train); % Standardized Data into same scale
save('testdata_DT',"testData") % Save test data for evaluation

%% Decision tree & tuning parameter 
% hyperparameter optimise by using for loop adjust two hyperparameters
leafs = [1:3:50]; %MinLeafSize
np = [1:3:50];   %MaxNumsplit

rng('default')
N = numel(leafs);
NN= numel(np);
err = [];
for n=1:N
    for m=1:NN
        t = fitctree(X_train,y_train,'CrossVal','On',...
            'MaxNumSplits',np(m),'MinLeafSize',leafs(n));
             err(n,m) = kfoldLoss(t);
    end
end

[minValue,I] = min(err(:)); %select the hyperparameter that minimise k-fold loss
[I_row, I_col] = ind2sub(size(err),I)

mdl_DT = fitctree(X_train,y_train,'CrossVal','On', 'MaxNumSplits',I_row,'MinLeafSize',I_col)
modelLosses = kfoldLoss(mdl_DT,'mode','individual');

%% check the performance when perform on training set
y_predict= predict(mdl_DT.Trained{1},X_train);
y_train_check= y_train{:,:};
confusion_score(y_train_check,y_predict)  % around 0.64 improve by 5%
%%
save("DT_final_model.mat",'mdl_DT') %save the model

%%
function confusion_score(x,y)
cm= confusionmat(x, y);
cmt = cm';

diagonal = diag(cmt);
sum_of_rows = sum(cmt, 2);

precision = diagonal ./ sum_of_rows;
DT_precision = mean(precision)

sum_of_columns = sum(cmt, 1);
recall = diagonal ./ sum_of_columns';
DT_recall = mean(recall)

DT_f1_score = 2*((DT_precision*DT_recall)/(DT_precision+DT_recall))
DT_Accuracy= (diagonal(1,1)+diagonal(2,1))/(sum_of_rows(1,1)+sum_of_rows(2,1))

figure
confusionchart(x,y)
title('Confusing Matrix')
end
