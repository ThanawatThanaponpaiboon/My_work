-----------------------------------------------------------------------------------------------------
ML coursework : instructions on how models should be run, including library or directory dependencies and required software versions
-----------------------------------------------------------------------------------------------------
- water_potability.csv is the dataset we used in this coursework.
- Initial_data_analyse.ipynb is the initial exploration of the Dataset to see the relationship between each feature and select the model for comparison.
-----------------------------------------------------------------------------------------------------
Step to run the model DT & RF
-----------------------------------------------------------------------------------------------------
1. Open train1.m & Run all train1.m file to produce decision tree model and test data for evaluation decision tree after tuning hyper-parameter. It takes a few moment to run because we use for loop run all through two hyper-parameters. We minimise the k-fold loss and compare all models for each set of model hyper-parameters to generate one final model for test set evaluation.

2. Open train2.m & Run all train2.m file to produce random forest model and test data for evaluation random forest after tuning hyper-parameter using optimalHyperparameter build-in function in MATLAB for adjust the hyper-parameter. 

3. Run test1.m to see the performance of the decision tree predicting target value from test set data. We use confusion matrix along with accuracy and F1 score to compare the performance between two model.

4. Run test2.m to see the performance of the random forest predicting target value from test set data. Likewise, the decision tree we use confusion matrix along with accuracy and F1 score to evaluate the model.

**FYI if it is not working you can also follow my step that has been recorded on my video mp4 file.
-----------------------------------------------------------------------------------------------------
Run by: macOS Ventura V.13.0.1
MATLAB version : R2022b(9.13.0.2049777)