-----------------------------------------------------------------------------------------------------
NLP coursework : instructions on how models should be run, including library or directory dependencies and required software versions
-----------------------------------------------------------------------------------------------------
- hate speech tweet from hugging face website is the dataset we used in this coursework.
-----------------------------------------------------------------------------------------------------
Step to run the model Logistic Regression & BERT Transformer.
-----------------------------------------------------------------------------------------------------
1. Open NLP_coursework.ipynb that is attached to this README.txt through zip file. You can open any platform that can execute Python but Colab is preferable.

2.Run through every step starting from import library and dataset from hugging face until split dataset in data preprocessing. You can skip the baseline method Keyword-based since it's not related to both comparison models.

3.Skip the part of ensemble learning with n-gram and go down to run bag of word + logistic regression this is the first comparison model that we will use to compare with BERT transformer.

4. Scroll down to the section BERT Transformer model and click run all, wait until you can see the result (This process might take up to 10 minutes we suggest that you can observe the result from the output that we already run)


**FYI if it is not working due to Colab crashing or any reason you can also go through the recorded on my video mp4 file on how my code should be run on Colab platform.
-----------------------------------------------------------------------------------------------------
Run by: macOS Ventura V.13.3.1
Environment : Google Colab